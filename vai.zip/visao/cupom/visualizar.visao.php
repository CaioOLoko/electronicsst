<h2>Descrição do Cupom</h2>

<strong>Código:</strong>      <?= $cupom['idcupom'] ?>
<strong>Nome:</strong>        <?= $cupom['nomecupom'] ?>
<strong>Desconto:</strong>        <?= $cupom['desconto'] ?>

<br><br>

<a href="./cupom/listarCupom" style="color:black; text-decoration: underline;">Voltar</a>

