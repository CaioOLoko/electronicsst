<div class="footer">
    <div class="title-footer">
        <h4>Electronic's ST</h4>
    </div>
    <div class="information-footer">
        <div class="contact-footer">
            <div class="social-web">
                <a href="https://www.facebook.com"><img class="social-web-img" src="./publico/img/footer/facebook.svg"></a>
                <a href="https://www.twitter.com"><img class="social-web-img" src="./publico/img/footer/twitter.svg"></a>
                <a href="https://br.linkedin.com"><img class="social-web-img" src="./publico/img/footer/inkscape.svg"></a>
            </div>
            <div class="address">
                <p>electronicsst@gmail.com</p>
                <p>Tel: (15) 3376-9930</p>
            </div>
        </div>
        <div class="address">
            <p>Av. João Olímpio de Oliveira, 1561 | Vila Asem | Itapetininga/SP</p>
            <p>CEP 18202-000</p>
        </div>
    </div>
    <div class="copyright">
        <p>&copy2018 by Electronic's ST. Proudly created by Samuel Facchetti de Matos | Thiago de Almeida Maciel</p>
    </div>
</div>