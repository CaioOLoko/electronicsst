<h2>Descrição da Categoria</h2>

<strong>Código:</strong>      <?= $categoria['idcategoria'] ?>
<strong>Descrição:</strong>        <?= $categoria['nomecategoria'] ?>

<br><br>

<a href="categoria/listarCategoria">Voltar</a>
