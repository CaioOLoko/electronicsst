<form action="" method="POST">

    <h1>Cadastro de Categoria</h1><br>

    <label for="nomecategoria">Descrição:</label><br> 
    <input type="text" maxlength="30" name="nomecategoria" style="width:250px" value="<?=@$categoria['nomecategoria']?>"><br><br>

    <button type="submit">Cadastrar</button>

</form>

