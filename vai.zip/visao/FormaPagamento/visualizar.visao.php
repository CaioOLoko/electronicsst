<h2>Descrição da Forma de Pagamento</h2>

<strong>Código:</strong>      <?= $formapagamento['idFormaPagamento'] ?>
<strong>Descrição:</strong>        <?= $formapagamento['descricao'] ?>

<br><br>

<a href="./FormaPagamento/listarFormaPagamento" style="color: black;text-decoration: underline">Voltar</a>

