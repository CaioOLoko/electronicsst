<?php

require_once "mailPHP/library.php";

function sendMail(){
    mail();
}

?>