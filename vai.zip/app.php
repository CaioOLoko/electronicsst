<?php

define('CONTROLADOR_PADRAO', 'paginas');
//define('URL_BASE', 'http://localhost/electronicsst/');
 define('URL_BASE', 'http://electronicsstofficial.000webhostapp.com/');

?>