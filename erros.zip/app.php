<?php

define('CONTROLADOR_PADRAO', 'paginas'); //por padrão vem definido o controlador de paginas estáticas (paginasControlador)
define('URL_BASE', 'http://camithamake.000webhostapp.com/');
// define('URL_BASE', 'http://localhost/template-MVC/');

?>