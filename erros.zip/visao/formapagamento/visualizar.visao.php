<h2> Ver detalhes da forma de pagamento </h2><br>
<p> Id: <?=$formapagamento ['idformapagamento']?> </p><br>
<p>Descrição: <?=$formapagamento ['descricao']?> </p><br>