<form action="" method="POST">
    Nome: <input type="text" name="nome">
    E-mail: <input type="text" name="email">
    Assunto: <input type="text" name="assunto">
    Mensagem: <input type="text" name="mensagem">
    <button type="submit">Enviar</button>
</form>