<h2> Ver detalhes da categoria </h2><br>
<p> Id: <?=$categoria ['idcategoria']?> </p><br>
<p>Descrição: <?=$categoria ['descricao']?> </p><br>