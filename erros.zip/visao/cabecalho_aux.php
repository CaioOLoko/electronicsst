<div class="header">
    <div class="logotype">
        <a href="." class="logo-store"><p class="title">CamiThaMake</p></a>
    </div>
</div>