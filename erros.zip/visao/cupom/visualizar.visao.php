<h2> Ver detalhes do Cupom </h2><br>
<p>Id Cupom: <?=$cupom ['idcupom']?> </p><br>
<p>Nome do Cupom: <?=$cupom  ['nomecupom']?> </p><br>
<p>Desconto: <?=$cupom ['desconto']?> </p><br>

