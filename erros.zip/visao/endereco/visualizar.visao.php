<h2> Ver detalhes do Endereço </h2>
<p>Id Usuário: <?=$endereco ['idendereco']?> </p>
<p>Logradouro: <?=$endereco ['logradouro']?> </p>
<p>Numero: <?=$endereco['numero']?> </p>
<p>Complemento: <?=$endereco ['complemento']?> </p>
<p>Bairro: <?=$endereco ['bairro']?> </p>
<p>Cidade: <?=$endereco ['cidade']?> </p>
<p>Cep: <?=$endereco ['cep']?> </p>


